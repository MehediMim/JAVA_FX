package util;

import models.Food;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class FoodFromFile {
    private static final String INPUT_FILE_NAME = "menu.txt";
    private static final String OUTPUT_FILE_NAME = "menu.txt";

    public static List<Food> readFromFile() throws Exception {
        List<Food> f = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(INPUT_FILE_NAME));
        //RestaurantDatabase restaurantDatabase=new RestaurantDatabase();
        while (true) {
            String line = br.readLine();
            if (line == null) break;
            //System.out.println(line);
            String[] array = line.split(",", -1);

            int id = Integer.parseInt(array[0]);
            String restaurantCategory = new String();
            restaurantCategory = array[1];
            String name = array[2];
            double score = Double.parseDouble(array[3]);

            Food food = new Food(id, restaurantCategory, name, score);

                f.add(food);
        }
            br.close();
            return f;

    }
    public static void WriteIntoFile(List<Food> foods) throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter(OUTPUT_FILE_NAME));


            for(Food food : foods) {
                bw.write(Integer.toString(food.getRestaurant_Id()) + "," + food.getCategory() + "," + food.getName() + "," + Double.toString(food.getPrice()));
                bw.newLine();
            }

        bw.close();


    }

}
