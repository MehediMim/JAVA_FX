package client;

import client.Fooditems;
import client.customerHome;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import models.Food;

import java.io.IOException;
import java.util.List;

public class FoodShowMain {
    @FXML
    private GridPane grid;

    @FXML
    private ScrollPane scroll;

    @FXML
    private Label nameLabel;

    public Label getNameLabel() {
        return nameLabel;
    }

    public void setNameLabel(Label nameLabel) {
        this.nameLabel = nameLabel;
    }

    private List<Food> foods;
    public customerHome _customerHome;

    public GridPane getGrid() {
        return grid;
    }

    public void setGrid(GridPane grid) {
        this.grid = grid;
    }

    public ScrollPane getScroll() {
        return scroll;
    }

    public void setScroll(ScrollPane scroll) {
        this.scroll = scroll;
    }

    public List<Food> getFoods() {
        return foods;
    }

    public void setFoods(List<Food> foods) {
        this.foods = foods;
    }

    public customerHome get_customerHome() {
        return _customerHome;
    }

    @FXML
    void BackButtonCalled(ActionEvent event) throws IOException, ClassNotFoundException {
        new customerHome(_customerHome);
    }

    public void set_customerHome(customerHome _customerHome) {
        this._customerHome = _customerHome;
    }

    private List<Food>getdata(){
        return foods;
    }
    public void init()
    {

        foods.addAll(getdata());

        int column =0;
        int row =1;
        try {
            for (int i = 0; i < foods.size(); i++) {
                nameLabel.setText(_customerHome.getUser().getName());

                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("fooditems.fxml"));
                AnchorPane anchorPane = fxmlLoader.load();

                System.out.println("Hello world");
                Fooditems itemController = fxmlLoader.getController();
                System.out.println("World hello");
                itemController.setData(foods.get(i),_customerHome);
                System.out.println("Woro");

                if (column == 3) {
                    column = 0;
                    row++;
                }

                grid.add(anchorPane, column++, row); //(child,column,row)
                //set grid width
                grid.setMinWidth(Region.USE_COMPUTED_SIZE);
                grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
                grid.setMaxWidth(Region.USE_PREF_SIZE);

                //set grid height
                grid.setMinHeight(Region.USE_COMPUTED_SIZE);
                grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
                grid.setMaxHeight(Region.USE_PREF_SIZE);

                GridPane.setMargin(anchorPane, new Insets(10));
            }
        } catch (IOException e) {
            System.out.println("HAE ERROR "+e);
        }

    }

    public void setMain(customerHome customerHome,List<Food>flist) {
        this._customerHome=customerHome;
        this.foods=flist;
    }
}
