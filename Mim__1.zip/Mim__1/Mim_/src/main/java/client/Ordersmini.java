package client;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import models.Food;
import models.Order;
import util.NetworkUtil;
import util.OrderRequest;
import util.Response;
import util.cancelOrder;

import java.io.IOException;
import java.util.Objects;
import java.util.Random;

public class Ordersmini {
    Order order;

    @FXML
    private Button acceptButton;

    @FXML
    private Label foodLabel;
//    @FXML
//    private ImageView picture;
//    private String[] imageUrls = {
//            "/image/5.jpg",
////            "/image/2.png",
////            "/image/3.png",
////            "/image/4.png",
//            //"image/fresh-pasta-with-hearty-bolognese-parmesan-cheese-generated-by-ai.jpg",
//            //"image/fresh-pasta-with-hearty-bolognese-parmesan-cheese-generated-by-ai.jpg"
//            // Add more image paths as needed
//    };
    @FXML
    private Label userlabel;
    RestaurantHome restaurantHome;

    NetworkUtil networkUtil;
    public void setData(Order order, RestaurantHome restaurantHome){
        this.order=order;
        foodLabel.setText(order.getFood().getName());
        //price.setText("$" +(String.valueOf(food.getPrice())));
        //category.setText((String) food.getCategory());
        userlabel.setText(order.getUser().getName());
        this.restaurantHome=restaurantHome;
        networkUtil=restaurantHome.getNetworkUtil();
//        Random random = new Random();
//        int randomIndex = random.nextInt(imageUrls.length);
//        String imageUrl = imageUrls[randomIndex];
//        Image image = new Image(Objects.requireNonNull(getClass().getResourceAsStream(imageUrl)));
//        picture.setImage(image);
    }

    @FXML
    void accpetButtonPressed(ActionEvent event) {
        acceptButton.disabledProperty();
        acceptButton.setText("DELIVERED");
        acceptButton.setStyle("-fx-background-color: #191970;");

        //System.out.println("button pressed for food "+food.getName());
        //OrderRequest orderRequest=new OrderRequest(_customerHome.getUser(),food);
        cancelOrder cancelOrder=new cancelOrder(order);
        try {
            System.out.println("WRITING in Server");
            networkUtil.write(cancelOrder);
        } catch (IOException e) {
            System.out.println("New Error "+e);
        }

    }
}
