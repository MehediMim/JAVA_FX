package client;


import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import models.User;
import project.mim_.*;
import requests.CustomerLogin;
import requests.RestaurantLogin;
import util.Customer;
import util.NetworkUtil;
import util.Registration;
import util.Response;

import java.io.IOException;
import java.util.Scanner;

public class Client {
    Response response;
    NetworkUtil networkUtil;
    Stage stage=new Stage();
    String username;
    String password;

    public Response getResponse() {
        return response;
    }

    public void setResponse(Response response) {
        this.response = response;
    }

    public NetworkUtil getNetworkUtil() {
        return networkUtil;
    }

    public void setNetworkUtil(NetworkUtil networkUtil) {
        this.networkUtil = networkUtil;
    }

    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Client()
    {
        try {

            networkUtil = new NetworkUtil("127.0.0.1", 44444);
//            while(true){
                showLoginPage();
                System.out.println("1. Restaurant");
                System.out.println("2. Customer");
                System.out.println("3. Exit");
                Scanner scanner=new Scanner(System.in);
//                int choice=Integer.parseInt(scanner.nextLine());
//                if(choice==1){
//                    clientisRestaurant();
//                }
//                if(choice==2){
//                    clientisCustomer();
//                }
//            }
        } catch (Exception e) {
            System.out.println("Line 45 : Client :"+ e );
        }
    }
    public NetworkUtil getnu()
    {
        return networkUtil;
    }


    public void showLoginPage ()  {
        // XML Loading using FXMLLoader
            try{


                FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
                System.out.println("51");
//                loader.setLocation(getClass().getResource("hello-view.fxml"));

                System.out.println("53");
                Parent root = null;
                try {
                    root = loader.load();
                } catch (Exception e) {
                    System.out.println("Line 59 : Client :" + e);
                }
                System.out.println("54");
                // Loading the controller
                LogInController controller = loader.getController();
                if(controller==null){
                    System.out.println("Null");
                }
                else {
                    System.out.println("Not null");
                }
                controller.setMain(this);
                controller.init();
                //controller.print("Hello Worlddddd");

                // Set the primary stage
                stage=new Stage();
                stage.setTitle("Login");
                //setIcon(stage);
                stage.setScene(new Scene(root));
                stage.show();
            }
            catch (Exception e){
                System.out.println("ERROR 76 "+ e);

            }

    }


    private void clientisCustomer() {
        System.out.println("1.Register");
        System.out.println("2.Login");

        //

        Scanner scanner2=new Scanner(System.in);
        int choice2=Integer.parseInt(scanner2.nextLine());
        if(choice2==1){
            RegisterNewCustomer();
        }
        if(choice2==2){
            LoginCustomer();
        }
    }



    private void clientisRestaurant() {                                        //Not Done
        System.out.println("1.Add Your Restaurant");
        System.out.println("2.Login into Restaurant");
        Scanner scanner3=new Scanner(System.in);
        int choice3=Integer.parseInt(scanner3.nextLine());
        if(choice3==1){
            RegisterNewRestuarant();
        }
        if(choice3==2){
            LoginRestaurant();
        }
    }

    private void LoginRestaurant() {
        Scanner _scanner=new Scanner(System.in);
        System.out.println("Enter Restaurant Name");
        String username=_scanner.nextLine();
        System.out.println("Enter Password");
        String password=_scanner.nextLine();
        try {
            RestaurantLogin restaurantLogin=new RestaurantLogin(username,password);
            System.out.println("HEllo World");
            networkUtil.write(restaurantLogin);
        } catch (IOException e) {
            System.out.println("line 81 : Client");
        }
        System.out.println("Respond Sent");
        try {
            Response response = (Response) networkUtil.read();

            if (response != null) {
                System.out.println("Response Received");
                System.out.println("Message: " + response.getMessage());
                System.out.println("Data: " + response.getData());
            } else {
                System.out.println("Received a null response from the server.");
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Line 95_ : Client "+e);
        }

    }

    private void RegisterNewRestuarant() {
        Scanner _scanner=new Scanner(System.in);
        System.out.println("Enter userName");
        String username=_scanner.nextLine();
        System.out.println("Enter Password");
        String password=_scanner.nextLine();
        try {
            networkUtil.write(new Registration(username,password));
        } catch (IOException e) {
            System.out.println("Line 109 : Client");
        }
        System.out.println("Respond Sent");
        try {
            Response response = (Response) networkUtil.read();

            if (response != null) {
                System.out.println("Response Received");
                System.out.println("Message: " + response.getMessage());
                System.out.println("Data: " + response.getData());
            } else {
                System.out.println("Received a null response from the server.");
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Line 123 : Client");
        }
    }


    public void LoginCustomer() {

        try {
            networkUtil.write(new CustomerLogin(username,password) );
        } catch (IOException e) {
            System.out.println("Line 137 : Client");
        }
        System.out.println("Respond Sent");
        try {
            Response response = (Response) networkUtil.read();

            if (response != null) {
                System.out.println("Response Received");
                System.out.println("Message: " + response.getMessage());
                System.out.println("Data: " + response.getData());
                if(response.getMessage().equals("E"))new customerHome(networkUtil, (User) response.getData(),stage);
                else LoginCustomer();
            } else {
                System.out.println("Received a null response from the server.");
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Line 153 : Client");
        }

    }

    private void RegisterNewCustomer() {
        Scanner _scanner=new Scanner(System.in);
        System.out.println("Enter userName");
        String username=_scanner.nextLine();
        System.out.println("Enter Password");
        String password=_scanner.nextLine();
        try {
            networkUtil.write(new Registration(username,password));
        } catch (IOException e) {
            System.out.println("Line 167 : Client");
        }
        System.out.println("Respond Sent");
        try {
            Response response = (Response) networkUtil.read();

            if (response != null) {
                System.out.println("Response Received");
                System.out.println("Message: " + response.getMessage());
                System.out.println("Data: " + response.getData());
            } else {
                System.out.println("Received a null response from the server.");
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Line 181 : Client");
        }

    }
//    private void exit() {
//        try {
//            if (networkUtil != null) {
//                networkUtil.closeConnection(); // Close the network connection
//            }
//            System.out.println("Exiting the program.");
//            System.exit(0); // Terminate the program
//        } catch (IOException e) {
//            System.out.println("Error while closing the network connection.");
//            e.printStackTrace();
//        }
//    }
    public static void main(String[] args) {
        new Client();
    }
}
