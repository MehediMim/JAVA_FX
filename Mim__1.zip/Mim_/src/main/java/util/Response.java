package util;

import java.io.Serializable;
public class Response implements Serializable{
    String message;
    Object data;

    public Response(String message, Object data) {
        this.message = message;
        this.data = data;
    }
    public Response()
    {
        this.message="";
        this.data=new Object();
    }
    public Response(String message)
    {
        this.message=message;
        this.data=new Object();
    }
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
