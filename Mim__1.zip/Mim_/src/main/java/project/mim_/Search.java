package project.mim_;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

import java.io.IOException;


public class Search {
    @FXML
    private TextArea searchForm;
    private int n;
    CustomerHomePage customerHomePage;
    public void searchButtonPressed(ActionEvent actionEvent) throws IOException, ClassNotFoundException {
        System.out.println("CLICKKK");
        System.out.println(n);
        String s=searchForm.getText();
        if(n==1){
            System.out.println("H");
            customerHomePage._customerHome.string=s;
            //customerHomePage.setStringFood(s);
            //System.out.println(customerHomePage.getStringFood());

            System.out.println("E");
            customerHomePage._customerHome.SearchFood();
            System.out.println("L");
            customerHomePage.stageoff();
            System.out.println("O");
        }
        if(n==2){
            customerHomePage.setStringRestaurant(s);
        }


    }

    public void setMain(CustomerHomePage customerHomePage,int n) {
        this.customerHomePage=customerHomePage;
        this.n=n;
    }

    public void init() {
    }
}
