package util;

public class OrdersOfARestaurant {

}
