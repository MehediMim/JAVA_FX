package models;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Restaurant implements Serializable {
    private int id;
    private String name;
    private double score;
    private String price;
    private String zip_code;
    private String []categories=new String[3];
    private  String password;

    volatile private List<Order>orderList=new ArrayList<>();

    public void setCategories(String[] categories) {
        this.categories = categories;
    }

    public void setPassword(String password) {
        this.password = password;
    }
     public  void addOrder(Order order){
        orderList.add(order);
     }
    public List<Order> getOrderListofARestaurant() {
        return orderList;
    }
    public void removeOrder(Order order)
    {
        System.out.println(orderList.size());
        System.out.println(order.getFood().getName() +"  removed");
        orderList.remove(order);
        orderList.remove(order.getFood().getRestaurant_Id());
        System.out.println(orderList.size());
    }

    public void setOrderListofARestaurant(List<Order> orderListofARestaurant) {
        this.orderList = orderListofARestaurant;
    }

    public Restaurant(int id, String name, double score, String price, String zip_code, String[] categories, String password) {
        this.id = id;
        this.name = name;
        this.score = score;
        this.price = price;
        this.zip_code = zip_code;
        this.categories = categories;
        this.password=password;
    }
    public Restaurant() {
    }
    public void temp_p(){
        System.out.print(id+" ");
        System.out.print(name+" ");
        System.out.print(score+" ");
        System.out.print(price+" ");
        System.out.print(zip_code+" ");
        System.out.print(categories[0]+" ");
        System.out.print(categories[1]+" ");
        System.out.println(categories[2]+" ");

    }

    public int getId() {
        return id;
    }

    public String[] getCategories() {
        return categories;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }
    public String getRating(){
        return Double.toString(this.score);
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getZip_code() {
        return zip_code;
    }

    public String getPassword(){return password;}

    public void setZip_code(String zip_code) {
        this.zip_code = zip_code;
    }
    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ",  password : "+password+", Score: " + score +
                ", Price: " + price + ", Zip Code: " + zip_code +
                ", Categories: " + categories[0] + ", " + categories[1] + ", " + categories[2];
    }

}
