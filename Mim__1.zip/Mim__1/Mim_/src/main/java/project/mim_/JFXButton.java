package project.mim_;

public class JFXButton {
}
