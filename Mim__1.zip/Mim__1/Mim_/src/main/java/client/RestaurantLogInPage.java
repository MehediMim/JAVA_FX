package client;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import models.Restaurant;
import project.mim_.CustomerHomePage;
import project.mim_.RestaurantAddLogin;
import requests.RestaurantLogin;
import util.NetworkUtil;
import util.Response;

import java.io.IOException;

public class RestaurantLogInPage {

    private String username_login;
    private String password_login;

    public void setnamePssword(String s,String p)
    {
        username_login=s;
        password_login=p;
    }

    NetworkUtil networkUtil;
    Stage stage;
    ActionEvent actionEvent;
    Restaurant restaurant;

    public String getUsername_login() {
        return username_login;
    }

    public void setUsername_login(String username_login) {
        this.username_login = username_login;
    }

    public String getPassword_login() {
        return password_login;
    }

    public void setPassword_login(String password_login) {
        this.password_login = password_login;
    }

    public NetworkUtil getNetworkUtil() {
        return networkUtil;
    }

    public void setNetworkUtil(NetworkUtil networkUtil) {
        this.networkUtil = networkUtil;
    }

    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public ActionEvent getActionEvent() {
        return actionEvent;
    }

    public void setActionEvent(ActionEvent actionEvent) {
        this.actionEvent = actionEvent;
    }

    public boolean isrEists() {
        return rEists;
    }

    public void setrEists(boolean rEists) {
        this.rEists = rEists;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public boolean rEists=false;
    public RestaurantLogInPage(NetworkUtil networkUtil, Stage stage, ActionEvent actionEvent) {

        this.actionEvent=actionEvent;
        this.networkUtil=networkUtil;
        this.stage=stage;
        try{
            System.out.println("Restaurant log In Page E Achi Bhai");

            FXMLLoader loader = new FXMLLoader(getClass().getResource("RestaurantAddLogin.fxml"));
            Parent root = null;
            try {
                root = loader.load();
            } catch (Exception e) {
                System.out.println("Line 59 : Client :" + e);
            }
            RestaurantAddLogin controller = loader.getController();
            controller.setMain(this);
            controller.init();

            // Set the primary stage
            //stage=new Stage();
            stage.setTitle("Customer");
            //setIcon(stage);
            stage.setScene(new Scene(root));
            stage.show();
        }
        catch (Exception e){
            System.out.println("ERROR 76 "+ e);

        }
    }

    public void password_check()
    {
        try {
            RestaurantLogin restaurantLogin=new RestaurantLogin(username_login,password_login);
            networkUtil.write(restaurantLogin);
            System.out.println(username_login);
            System.out.println(password_login);
        } catch (IOException e) {
            System.out.println(e);
        }
        try {
            Response response = (Response) networkUtil.read();
            if (response != null && response.getMessage().equals("E")) {
//                System.out.println("Response Received");
//                System.out.println("Message: " + response.getMessage());
//                System.out.println("Data: " + response.getData());

                restaurant=(Restaurant) response.getData();
                rEists=true;
            } else {
                System.out.println("Received a null response from the server.");
            }
        } catch (Exception e) {
            System.out.println("Line 95 : Client "+e);
        }
    }

}
