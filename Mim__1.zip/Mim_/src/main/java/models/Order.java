package models;

import util.Customer;

import java.io.Serializable;

public class Order implements Serializable {
    User user;
    Food food;


    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Food getFood() {
        return food;
    }

    public void setFood(Food food) {
        this.food = food;
    }

    public Order(User user, Food food) {
        this.user = user;
        this.food = food;
    }

    public Order getData() {
        return this;
    }
}
