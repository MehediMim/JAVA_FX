package models;

import java.io.Serializable;

public class Food implements Serializable {
    private int restaurant_Id;
    private String category;
    private String name;
    private double price;

    public Food(int restaurant_Id, String category, String name, double price) {
        this.restaurant_Id = restaurant_Id;
        this.category = category;
        this.name = name;
        this.price = price;
    }

    public int getRestaurant_Id() {
        return restaurant_Id;
    }

    public void setRestaurant_Id(int restaurant_Id) {
        this.restaurant_Id = restaurant_Id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    @Override
    public String toString() {
        return "Restaurant ID: " + restaurant_Id + ", Category: " + category +
                ", Name: " + name + ", Price: " + price;
    }
}
