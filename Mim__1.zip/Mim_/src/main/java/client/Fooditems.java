package client;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import models.Food;
import models.Order;
import project.mim_.CustomerHomePage;
import requests.CustomerLogin;
import util.NetworkUtil;
import util.OrderRequest;
import util.Response;

import java.io.IOException;

public class Fooditems {

    public Food food;

    @FXML
    private Label foodname;

    @FXML
    private Label category;

    @FXML
    private Label price;

    @FXML
    private Button orderButtonPressed;

    customerHome _customerHome;
    NetworkUtil networkUtil;

    public void setData(Food food,customerHome customerHome){
        this.food=food;
        foodname.setText((String) food.getName());
        price.setText("$" +(String.valueOf(food.getPrice())));
        category.setText((String) food.getCategory());
        this._customerHome=customerHome;
        networkUtil=_customerHome.getNetworkUtil();
    }

    public void button(ActionEvent actionEvent) {
        orderButtonPressed.disabledProperty();
        orderButtonPressed.setText("ORDERED");
        orderButtonPressed.setStyle("-fx-background-color: #191970;");

        System.out.println("button pressed for food "+food.getName());
        OrderRequest orderRequest=new OrderRequest(_customerHome.getUser(),food);
        try {
            System.out.println("WRITING in Server");
            networkUtil.write(orderRequest);
        } catch (IOException e) {
            System.out.println("New Error "+e);
        }

    }
}
