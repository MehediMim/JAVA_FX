package project.mim_;

import client.Client;
import client.RestaurantLogInPage;
import client.customerHome;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import models.User;
import requests.CustomerLogin;
import util.Customer;
import util.NetworkUtil;
import util.Response;

import java.io.IOException;

public class LogInController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    private Button loginbutton;

    @FXML
    private JFXButton loginButton;

    @FXML
    private JFXButton registrationButton;

    @FXML
    private JFXButton restaurantRegistrationButton;

    NetworkUtil networkUtil;
    @FXML
    private TextArea usernameForm;

    @FXML
    private TextArea passwordForm;

    @FXML
    private ImageView logoImage;

    @FXML
    private Text alreadyHaveAccountText;
    Client client;
    public void setMain(Client client) {
        this.client=client;
    }

    public void init() {
        this.networkUtil=client.getNetworkUtil();
    }



    public void RestAurantRegistrationButtonPressed(ActionEvent actionEvent) throws IOException, ClassNotFoundException {
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        new RestaurantLogInPage(client.getNetworkUtil(),stage,actionEvent);

    }

    public void customerloginButtonPressed(ActionEvent actionEvent) {
        //client.setUsername(usernameForm.getText());
        String username = usernameForm.getText();
        String password = passwordForm.getText();
        //client.setPassword(passwordForm.getText());
        //System.out.println(username);
        //System.out.println(password);
        //client.LoginCustomer();
        try {
            networkUtil.write(new CustomerLogin(username,password) );
        } catch (IOException e) {
            System.out.println("Line 137 : Client");
        }
        System.out.println("Respond Sent_");
        try {
            Response response = (Response) networkUtil.read();
            System.out.println("Respond Sent_");

            if (response != null) {
                System.out.println("Response Received");
                System.out.println("Message: " + response.getMessage());
                System.out.println("Data: " + response.getData());
                if(response.getMessage().equals("E")) {
                    Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                    new customerHome(networkUtil, (User) response.getData(), stage);
                }
            }
            //else LoginCustomer();
        } catch (Exception ex) {
            System.out.println("101 + "+ex);
        }
    }





    public void customerRegistrationbuttonPressed(ActionEvent actionEvent) {
    }
}