package util;

import models.Restaurant;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class RestaurantFromFile{
    private static final String INPUT_FILE_NAME = "restaurant.txt";
    private static final String OUTPUT_FILE_NAME = "restaurant.txt";
    public static List<Restaurant> readFromFile() throws Exception  {
        List<Restaurant> res = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(INPUT_FILE_NAME));
        //RestaurantDatabase restaurantDatabase=new RestaurantDatabase();
        while (true) {
            String line = br.readLine();
            if (line == null) break;
            //System.out.println(line);
            String [] array = line.split(",", -1);

            int id=Integer.parseInt(array[0]);
            String name=array[1];
            String password=array[2];
            double score=Double.parseDouble(array[3]);
            String price=array[4];
            String zip_code=array[5];
            String []category=new String[3];
            category[0]=array[6];
            category[1]=array[7];
            category[2]=array[8];
            Restaurant restaurant=new Restaurant(id,name,score,price,zip_code,category,password);
            res.add(restaurant);
        }
        br.close();
        return res;


    }
    public static void WriteIntoFile(List<Restaurant> restaurants) throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter(OUTPUT_FILE_NAME));

        for(Restaurant r : restaurants) {


            String Catagories = String.join(",", r.getCategories());
            bw.write(Integer.toString(r.getId())+","+r.getName()+","+r.getPassword()+","+Double.toString(r.getScore())+","+r.getPrice()+","+r.getZip_code()+","+Catagories);
            bw.newLine();
        }
        bw.close();

    }

}
