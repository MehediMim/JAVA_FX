package Servers;

import models.Food;
import models.Order;
import models.Restaurant;
import requests.CustomerLogin;
import requests.RestaurantLogin;
import util.*;

import java.util.List;

public class ServerRequestThread implements Runnable {
    private RestaurantDatabase restaurantDatabase;
    private NetworkUtil networkUtil;


    public ServerRequestThread(RestaurantDatabase restaurantDatabase, NetworkUtil networkUtil) {
        this.restaurantDatabase = restaurantDatabase;
        this.networkUtil = networkUtil;
        Thread t = new Thread(this);
        t.start();
    }

    @Override
    public void run() {
        try {
            while (true) {
                Object request = networkUtil.read();
                if(request instanceof Load){
                    System.out.println("HEre");
                    List<Order>ol=restaurantDatabase.getRestaurantOrderList(((Load) request).getRestaurant());
                    for(Order order:ol){
                        System.out.println(order.getFood().getName());
                    }
                    networkUtil.write(ol);
                }
                if(request instanceof cancelOrder){
                    restaurantDatabase.cancelOrder( ((cancelOrder) request).getOrder());
                }
                if(request instanceof FoodAdd){
                    System.out.println("ADD REUEST");
                    restaurantDatabase.AddFood((FoodAdd) request);
                }
                if(request instanceof Restaurant){
                    List<Order>ol=restaurantDatabase.getRestaurantOrderList((Restaurant) request);
                    networkUtil.write(ol);
                }
                if(request instanceof RegisterRequest){
                    restaurantDatabase.addRestaurantNew((RegisterRequest) request);
                }

                if (request instanceof CustomerLogin) {
                    CustomerLogin customerLogin = (CustomerLogin) request;
                    System.out.println("Login Request Received_");
                    System.out.println("KORCHI ONEK KICHU");
                    Response response = restaurantDatabase.DoCustomerExists(customerLogin.getUsername(), customerLogin.getPassword());
                    networkUtil.write(response);

                }
                else if (request instanceof OrderRequest) {
                    System.out.println("ORDER REQUEST RECIEVED");
                    restaurantDatabase.orderwithoutRestaurant(((OrderRequest) request).getFood(),((OrderRequest) request).getUser());

                }
                else if (request instanceof RestaurantLogin) {
                    RestaurantLogin restaurantLogin = (RestaurantLogin) request;
                    System.out.println("Restaurant log in request Received");
                    Response response = restaurantDatabase.DoRestaurantExists(restaurantLogin.getRestaurantname(), restaurantLogin.getRestaurantpassword());
                    networkUtil.write(response);
                }
                else if(request instanceof Response){
                    //System.out.println("Something Recieved");
                    if(((Response) request).getMessage().equals("SearchRestaurant")){
                        System.out.println("Search Restaurant request Recived");
                        //Response _response=new Response();
                        //_response.setMessage("Hello world");
                        //String name= (String) ((Response) request).getData();
                        //System.out.println(name);
                        List<Food>ol=restaurantDatabase.getFoodNew((String) ((Response) request).getData());
                        System.out.println("Writing");
                        networkUtil.write(ol);
//                        List<Restaurant>restaurantList=(List<Restaurant>) _response.getData();
//                        for (Restaurant restaurant:restaurantList){
//                            System.out.println(restaurant);
//                        }
                        //networkUtil.write(_response);
                    }
                    if(((Response) request).getMessage().equals("SearchFood")){
                        //System.out.println("Search Food request Recived");
                        Response _response=new Response();
                        //_response.setMessage("Hello world");
                        String name= (String) ((Response) request).getData();
                        System.out.println(name);
                        _response.setData(restaurantDatabase.SearchForFoodWithName(name));
//                        List<Restaurant>restaurantList=(List<Restaurant>) _response.getData();
//                        for (Restaurant restaurant:restaurantList){
//                            System.out.println(restaurant);
//                        }
                        networkUtil.write(_response);
                    }if(((Response) request).getMessage().equals("list")){
                        List<Food>fl=restaurantDatabase.getFoodOfRestaurant((Restaurant) ((Response) request).getData());
                        networkUtil.write(fl);
                    }
                    if(((Response) request).getMessage().equals("SearchCategory")){
                        System.out.println("Search Food request Recived");
                        Response _response=new Response();
                        _response.setMessage("Hello world");
                        String name= (String) ((Response) request).getData();
                        System.out.println(name);
                        _response.setData(restaurantDatabase.SearchForFoodWithCategory(name));
//                        List<Restaurant>restaurantList=(List<Restaurant>) _response.getData();
//                        for (Restaurant restaurant:restaurantList){
//                            System.out.println(restaurant);
//                        }
                        networkUtil.write(_response);
                    }


                }
                if(request instanceof Registration){
                    System.out.println("Registration request Found: 82 ");
                    Response response=new Response("Successfully Added","");
                    restaurantDatabase.addCustomer(((Registration) request).getUsername(),((Registration) request).getPassword());
                    networkUtil.write(response);
                }
            }
        }
        catch (Exception e) {
            // Handle client disconnection here
            System.out.println("Line 91 : ServerThread " + e.getMessage());
        }
//        finally {
//            // Close the networkUtil and any other resources here
//            try {
//                networkUtil.closeConnection();
//            } catch (Exception e) {
//                // Handle any exceptions that occur during resource cleanup
//                System.out.println("Line 99 : ServerThread " + e.getMessage());
//            }
//        }
    }
}
