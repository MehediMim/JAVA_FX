package util;

import models.Order;

import java.io.Serializable;
import java.util.List;

public class OrderlIst implements Serializable {
    List<Order>orderList;

    public List<Order> getOrderList() {
        return orderList;
    }

    public void setOrderList(List<Order> orderList) {
        this.orderList = orderList;
    }

    public OrderlIst(List<Order> orderList) {
        this.orderList = orderList;
    }
}
