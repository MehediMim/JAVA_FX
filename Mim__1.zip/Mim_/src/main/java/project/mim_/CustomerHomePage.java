package project.mim_;

import client.customerHome;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import util.NetworkUtil;

import java.io.IOException;

public class CustomerHomePage {
    String stringfood;
    String stringrestaurant;

    public customerHome _customerHome;
    NetworkUtil networkUtil;
    Stage stage=new Stage();

    public String getStringFood() {
        return stringfood;
    }
    public String getStringRestaurant() {
        return stringfood;
    }
    public void stageoff()
    {
        stage.close();;
    }

    public void setStringFood(String string) {
        this.stringfood = string;
    }
    public void setStringRestaurant(String string) {
        this.stringrestaurant = string;
    }

    public void setMain(customerHome customerHome) {
        this._customerHome=customerHome;
    }

    public void init() {

    }

    public void restaurantSearch(ActionEvent actionEvent) {
        //_customerHome.SearchCategory();
        try{
            System.out.println("Search Box Call korchi bhai e acghi bhai");

            FXMLLoader loader = new FXMLLoader(getClass().getResource("search.fxml"));
            Parent root = null;
            try {
                root = loader.load();
            } catch (Exception e) {
                System.out.println("Line 43 : SEarch :" + e);
            }
            // Loading the controller
            Search controller = loader.getController();
            controller.setMain(this,2);
            controller.init();

            // Set the primary stage
            stage=new Stage();
            stage.setTitle("Customer");
            //setIcon(stage);
            stage.setScene(new Scene(root));
            stage.show();
        }
        catch (Exception e){
            System.out.println("ERROR 76 "+ e);

        }

    }

    public void categorySearch(ActionEvent actionEvent) throws IOException, ClassNotFoundException {
        //_customerHome.SearchCategory();
        try{
            System.out.println("Search Box Call korchi bhai e acghi bhai");

            FXMLLoader loader = new FXMLLoader(getClass().getResource("search.fxml"));
            Parent root = null;
            try {
                root = loader.load();
            } catch (Exception e) {
                System.out.println("Line 43 : SEarch :" + e);
            }
            // Loading the controller
            Search controller = loader.getController();
            controller.setMain(this,3);
            controller.init();

            // Set the primary stage
            stage=new Stage();
            stage.setTitle("Customer");
            //setIcon(stage);
            stage.setScene(new Scene(root));
            stage.show();
        }
        catch (Exception e){
            System.out.println("ERROR 76 "+ e);

        }
    }

    public void foodSearch(ActionEvent actionEvent) {
        //_customerHome.SearchCategory();
        try{
            System.out.println("Search Box Call korchi bhai e acghi bhai");

            FXMLLoader loader = new FXMLLoader(getClass().getResource("search.fxml"));
            Parent root = null;
            try {
                root = loader.load();
            } catch (Exception e) {
                System.out.println("Line 43 : SEarch :" + e);
            }
            // Loading the controller
            Search controller = loader.getController();
            controller.setMain(this,1);
            controller.init();

            // Set the primary stage
            stage=new Stage();
            stage.setTitle("Customer");
            //setIcon(stage);
            stage.setScene(new Scene(root));
            stage.show();
        }
        catch (Exception e){
            System.out.println("ERROR 76 "+ e);

        }
    }

    public void searchByName() throws IOException, ClassNotFoundException {
        System.out.println("perfect");
        //_customerHome.setString(stringfood);
        //_customerHome.string=stringfood;
        System.out.println("???perfect");
        _customerHome.SearchFood();
    }
}
