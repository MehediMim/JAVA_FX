package Servers;

import models.Food;
import models.Restaurant;
import models.User;
import util.FoodFromFile;
import util.NetworkUtil;
import util.RestaurantFromFile;
import util.UserFromFile;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {
    public static void main(String[] args) throws Exception {
        List<Food> foodList = new ArrayList<>();
        List<Restaurant> restaurantList = new ArrayList<>();
        List<User> userList = new ArrayList<>();

        RestaurantDatabase restaurantDatabase;
        restaurantList = RestaurantFromFile.readFromFile();
        System.out.println("Restaurant List Loaded...");
        foodList = FoodFromFile.readFromFile();
        System.out.println("Food List Loaded...");
        userList = UserFromFile.readFromFile();
        System.out.println("User List Loaded...");
        restaurantDatabase = new RestaurantDatabase(restaurantList, foodList, userList);
        System.out.println(restaurantList.size());
        System.out.println(foodList.size());
        System.out.println(userList.size());

        try (ServerSocket serverSocket = new ServerSocket(44444)) {
            while (true) {
                System.out.println("Server is running...");
                restaurantDatabase.print();
                Socket socket = serverSocket.accept();
                System.out.println("New Client connected");
                NetworkUtil networkUtil = new NetworkUtil(socket);
                new ServerRequestThread(restaurantDatabase, networkUtil);
            }
        } catch (Exception e) {
            System.out.println("line 40 : Server " + e.getMessage());
        }
    }
}
