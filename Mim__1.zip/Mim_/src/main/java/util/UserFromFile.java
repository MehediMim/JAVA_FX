package util;

import models.User;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class UserFromFile {
    private static final String INPUT_FILE_NAME = "customer.txt";
    private static final String OUTPUT_FILE_NAME = "customer.txt";

    public static List<User> readFromFile() throws Exception {
        List<User> u = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(INPUT_FILE_NAME));
        //RestaurantDatabase restaurantDatabase=new RestaurantDatabase();
        while (true) {
            String line = br.readLine();
            if (line == null) break;
            //System.out.println(line);
            String[] array = line.split(",", -1);

            int id = Integer.parseInt(array[0]);
            String name = new String();
            name = array[1];
            String password = array[2];


            User user=new User(id,name,password);

            u.add(user);
        }
        br.close();
        return u;

    }
    public static void WriteIntoFile(List<User> users) throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter(OUTPUT_FILE_NAME));


        for(User user : users) {
            bw.write(Integer.toString(user.getId()) + "," + user.getName() + "," + user.getPassword()  );
            bw.newLine();
        }

        bw.close();

    }

}
