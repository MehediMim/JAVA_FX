package client;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import models.Food;
import models.Order;
import util.NetworkUtil;
import util.OrderRequest;
import util.Response;
import util.cancelOrder;

import java.io.IOException;

public class Ordersmini {
    Order order;

    @FXML
    private Button acceptButton;

    @FXML
    private Label foodLabel;

    @FXML
    private Label userlabel;
    RestaurantHome restaurantHome;

    NetworkUtil networkUtil;
    public void setData(Order order, RestaurantHome restaurantHome){
        this.order=order;
        foodLabel.setText(order.getFood().getName());
        //price.setText("$" +(String.valueOf(food.getPrice())));
        //category.setText((String) food.getCategory());
        userlabel.setText(order.getUser().getName());
        this.restaurantHome=restaurantHome;
        networkUtil=restaurantHome.getNetworkUtil();
    }

    @FXML
    void accpetButtonPressed(ActionEvent event) {
        acceptButton.disabledProperty();
        acceptButton.setText("DELIVERED");
        acceptButton.setStyle("-fx-background-color: #191970;");

        //System.out.println("button pressed for food "+food.getName());
        //OrderRequest orderRequest=new OrderRequest(_customerHome.getUser(),food);
        cancelOrder cancelOrder=new cancelOrder(order);
        try {
            System.out.println("WRITING in Server");
            networkUtil.write(cancelOrder);
        } catch (IOException e) {
            System.out.println("New Error "+e);
        }

    }
}
