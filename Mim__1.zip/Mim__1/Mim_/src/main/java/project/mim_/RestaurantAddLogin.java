package project.mim_;

import client.RestaurantHome;
import client.RestaurantLogInPage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import util.RegisterRequest;

import java.io.IOException;

public class RestaurantAddLogin {
    @FXML
    private TextArea category1;

    @FXML
    private TextArea category2;

    @FXML
    private TextArea category3;

    @FXML
    private TextArea name;

    @FXML
    private TextArea password;

    @FXML
    private TextArea price;

    @FXML
    private TextArea rating;


    @FXML
    private TextArea zipcode;


    @FXML
    private TextArea restaurantNamePassword;

    @FXML
    private TextArea restaurantNamelogIn;
    RestaurantLogInPage restaurantLogInPage;

    @FXML
    public void restaurantLogInButtonPressed(ActionEvent actionEvent) {
        System.out.println("BUTTON PRESSED");
        restaurantLogInPage.setnamePssword(restaurantNamelogIn.getText(),restaurantNamePassword.getText());
        restaurantLogInPage.password_check();
        if(restaurantLogInPage.rEists==true) //Call New Restaurant client
        {
            System.out.println("ILL CALL RESTAURANT CLIENT");
            new RestaurantHome(restaurantLogInPage.getRestaurant(),restaurantLogInPage.getNetworkUtil(),restaurantLogInPage.getActionEvent(),restaurantLogInPage.getStage());
        }
    }

    public void RestaurantRegistrationButtonPressed(ActionEvent actionEvent) throws IOException {
        String cat1= category1.getText();

        String cat2 = category2.getText();

        String cat3 = category3.getText();

        String  Name= name.getText();

        String Password= password.getText();

        String Price= price.getText();

        String Rating =  rating.getText();


        String Zipcode = zipcode.getText();
        RegisterRequest registerRequest =new RegisterRequest(cat1, cat2, cat3, Name,  Password,  Price,  Rating,Zipcode);
        restaurantLogInPage.getNetworkUtil().write(registerRequest);
    }

    public void setMain(RestaurantLogInPage restaurantLogInPage) {
        this.restaurantLogInPage=restaurantLogInPage;
    }

    public void init() {
    }
}
