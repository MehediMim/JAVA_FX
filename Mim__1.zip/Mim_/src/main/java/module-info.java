module project.mim_ {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;

    opens project.mim_ to javafx.fxml;
    exports project.mim_;
    exports client;
    opens client to javafx.fxml;
}