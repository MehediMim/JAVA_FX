package project.mim_;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import models.Food;
import client.*;

import java.io.IOException;
import java.util.List;

public class MenuSHow {

    @FXML
    private AnchorPane black;

    @FXML
    private GridPane grid;

    @FXML
    private Label qwe;

    @FXML
    private ScrollPane scroll;
    RestaurantHomePageControl restaurantHomePageControl;
    List<Food>foodList;
    public void setMain(RestaurantHomePageControl restaurantHomePageControl, List<Food> foodList) {
        this.restaurantHomePageControl=restaurantHomePageControl;
        this.foodList=foodList;
    }

    public void init() throws IOException, ClassNotFoundException {
        //LoadMenu();
    }
//    public void LoadMenu() throws IOException, ClassNotFoundException {
//        //List<Order>orderList;
//        //orderList=restaurantHome.getListt();
//        //System.out.println("Orderlist size"+orderList.size());
//        //orders.clear();
//        //orders=;
//        //orders.addAll(getOrders());
//
//        int column =0;
//        int row =1;
//        try {
//            for (int i = 0; i < foodList.size(); i++) {
//                //nameLabel.setText(_customerHome.getUser().getName());
//
//                FXMLLoader fxmlLoader = new FXMLLoader();
//                fxmlLoader.setLocation(getClass().getResource("fooditems2.fxml"));
//                AnchorPane anchorPane = fxmlLoader.load();
//
//                System.out.println("Hello world");
//                Fooditems2 itemController = fxmlLoader.getController();
//                System.out.println("World hello");
//                itemController.setData(foodList.get(i));
//                System.out.println("Woro");
//
//                if (column == 3) {
//                    column = 0;
//                    row++;
//                }
//
//                grid.add(anchorPane, column++, row); //(child,column,row)
//                //set grid width
//                grid.setMinWidth(Region.USE_COMPUTED_SIZE);
//                grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
//                grid.setMaxWidth(Region.USE_PREF_SIZE);
//
//                //set grid height
//                grid.setMinHeight(Region.USE_COMPUTED_SIZE);
//                grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
//                grid.setMaxHeight(Region.USE_PREF_SIZE);
//
//                GridPane.setMargin(anchorPane, new Insets(10));
//            }
//        } catch (IOException e) {
//            System.out.println("HAE__ERROR "+e);
//        }
//    }

    public void BackButtonCalled(ActionEvent actionEvent) {
    }
}
