package project.mim_;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import util.FoodAdd;

import java.io.IOException;

public class AddFood {
    @FXML
    private TextArea category;

    @FXML
    private TextArea name;

    @FXML
    private TextArea price;
    RestaurantHomePageControl restaurantHomePageControl;

    @FXML
    void ADD(ActionEvent event) throws IOException {
        String _name=name.getText();
        String _category=category.getText();
        String _price=price.getText();
        FoodAdd foodAdd=new FoodAdd(restaurantHomePageControl._restaurantHome.getRestaurant().getId(),_name,_category,_price);
        restaurantHomePageControl._restaurantHome.getNetworkUtil().write(foodAdd);
        restaurantHomePageControl.AddfoodOff();
    }
    public void setMain(RestaurantHomePageControl restaurantHomePageControl) {
    this.restaurantHomePageControl=restaurantHomePageControl;
    }

    public void init() {
    }
}
