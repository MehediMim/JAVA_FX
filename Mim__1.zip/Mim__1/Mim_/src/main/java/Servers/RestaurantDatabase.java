package Servers;

import models.Food;
import models.Order;
import models.Restaurant;
import models.User;
import util.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class RestaurantDatabase implements Serializable {

    public void cancelOrder(Order order) {

        System.out.println("Canceling order");
        for(Restaurant restaurant:restaurantList){
            if(restaurant.getId()==order.getFood().getRestaurant_Id()){
                restaurant.removeOrder(order);
            }
        }
    }

    public void addRestaurantNew(RegisterRequest request) throws Exception {
        Restaurant restaurant=new Restaurant(restaurantList.size()+1,
                request.getCategory1(),request.getCategory2(),
                request.getCategory3(),
                request.getName(),
                request.getPassword(),
                request.getPrice(),
                request.getRating(),
                request.getZipcode());
        restaurantList.add(restaurant);
        RestaurantFromFile.WriteIntoFile(restaurantList);

    }

    public void AddFood(FoodAdd foodAdd) throws Exception {

//        for(Restaurant restaurant:restaurantList){
//            if(foodAdd.getId()==restaurant.getId()){
//                f
//            }
//        }
        foodList.add(new Food(foodAdd.getId(),foodAdd.getCategory(),foodAdd.getName(),Double.parseDouble(foodAdd.getPrice())));
        FoodFromFile.WriteIntoFile(foodList);
    }

    public List<Food> getFoodNew(String data) {
        System.out.println("here in Database");
        //Restaurant restaurant=new Restaurant();
        Restaurant restaurant=new Restaurant();
        for(Restaurant res:restaurantList){
            if(res.getName().equalsIgnoreCase(data)){
                restaurant=res;
            }
        }
        System.out.println("here in Database");
        List<Food>fl=new ArrayList<>();
        for(Food food:foodList){
            if(food.getRestaurant_Id()==restaurant.getId()){
                fl.add(food);
            }
        }
        System.out.println("here in Database "+fl.size());
        return fl;
    }

    public class nameandCount{
        String name=new String();
        int count=0;
    }

    private List<Restaurant> restaurantList ;

    private  List<User>userlist ;
    private List<Food> foodList ;
    private List<String> categoryListOfRestaurant = new ArrayList<>();
    private List<nameandCount> nameandCounts = new ArrayList<>();

    public void print()
    {
        for(Restaurant restaurant:restaurantList){
            System.out.println(restaurant.getName()+restaurant.getOrderListofARestaurant().size());
        }
    }

    public List<Restaurant> getRestaurantList(){
        return restaurantList;
    }
    public List<Food> getFoodList(){
        return foodList;
    }
    public List<Order> getRestaurantOrderList(Restaurant restaurant){
        System.out.println("Here is size "+restaurant.getOrderListofARestaurant().size());
        for(Restaurant res:restaurantList){
            if(res.getId()==restaurant.getId()){
                return res.getOrderListofARestaurant();
            }
        }
        return restaurant.getOrderListofARestaurant();

        //return  restaurant.getOrderListofARestaurant();                                           //////////////////
    }
    public List<Food> getFoodOfRestaurant(Restaurant r)
    {
        List<Food>fl=new ArrayList<>();
        for(Food food:foodList){
            if(food.getRestaurant_Id()==r.getId()){
                fl.add(food);
            }
        }
        return fl;
    }

    public void orderwithoutRestaurant(Food food, User user) {
        System.out.println("TRIGGERED");
        int id;
        id=food.getRestaurant_Id();
        for(Restaurant restaurant:restaurantList){
            if(restaurant.getId()==id){
                restaurant.addOrder(new Order(user,food));
                System.out.println("NEW ORDER PLACED @ "+restaurant.getName());
                System.out.println(restaurant.getName()+restaurant.getOrderListofARestaurant().size());
            }
        }
    }


    //    public boolean subStringBelongs(String sub,String main){
////        return main.toLowerCase().contains(sub.toLowerCase());
////
//    }
    public boolean subStringBelongs(String sub, String main) {
        sub = sub.toLowerCase();
        main = main.toLowerCase();

        if (main.contains(sub)) {
            int i = main.indexOf(sub);
            if (i == 0) {
                return true;
            } else if (i > 0) {
                char characterBeforeSub = main.charAt(i - 1);
                return characterBeforeSub == ' ';
            }
        }

        return false;
    }


    public List<String> getCategoryListOfRestaurant() {
        return categoryListOfRestaurant;
    }
    public List<nameandCount> getNameWithCount() {
        List<nameandCount>Listt=new ArrayList<>();
        for(int i=0;i< restaurantsize();i++){
            int count=0;
            for(int j=0;j<foodList.size();j++){
                if(foodList.get(j).getRestaurant_Id()==restaurantList.get(i).getId())count++;
            }
            nameandCount temp=new nameandCount();
            temp.name=restaurantList.get(i).getName();
            temp.count=count;

            Listt.add(temp);
        }
        return Listt;
    }
    public void Addorder(Food food, User user, Restaurant restaurant)
    {
        Order order=new Order(user,food);
        restaurant.addOrder(order);
    }
    public List<Restaurant> getListOfRetaurantBasedOnCategoryname(String s){
        List<Restaurant>l=new ArrayList<>();
        for(int i=0;i<restaurantList.size();i++){
            if(restaurantList.get(i).getCategories()[0].equalsIgnoreCase(s)) l.add(restaurantList.get(i));
            if(restaurantList.get(i).getCategories()[1].equalsIgnoreCase(s)) l.add(restaurantList.get(i));
            if(restaurantList.get(i).getCategories()[2].equalsIgnoreCase(s)) l.add(restaurantList.get(i));
        }
        return l;
    }

    public RestaurantDatabase() throws Exception {
//        restaurantList = RestaurantFromFile.readFromFile();
//        foodList=FoodFromFile.readFromFile();
//        for(int i=0;i<restaurantList.size();i++){
//            if(restaurantList.get(i).getCategories()[0]!=null)addInCategoryList(restaurantList.get(i).getCategories()[0]);
//            if(restaurantList.get(i).getCategories()[1]!=null)addInCategoryList(restaurantList.get(i).getCategories()[1]);
//            if(restaurantList.get(i).getCategories()[2]!=null)addInCategoryList(restaurantList.get(i).getCategories()[2]);
//        }
    }
    public RestaurantDatabase(List<Restaurant>rl,List<Food>fl,List<User>ul)throws Exception{
        restaurantList=rl;
        foodList=fl;
        userlist=ul;
    }
    public Response DoCustomerExists(String name,String password)
    {
        System.out.println("TRIGGERED");
        Response response=new Response("N");
        for(User user:userlist){
            if(user.getName().equalsIgnoreCase(name) && user.getPassword().equals(password)){
                response= new Response("E",user);

            }
        }
        return response;
    }
    public Response DoRestaurantExists(String name,String password)
    {

        for(Restaurant restaurant:restaurantList){
            if(restaurant.getName().equalsIgnoreCase(name) && restaurant.getPassword().equals(password)){
                //int i=restaurant.getId();
                return new Response("E",restaurant);
            }
        }
        return new Response("N",new Restaurant());
    }
    public int restaurantsize(){
        return restaurantList.size();
    }
    public boolean _containsinRestaurantList(Restaurant r,List<Restaurant> rList){

        for(int i=0;i<rList.size();i++){
            if(rList.get(i).getName().equalsIgnoreCase(r.getName())){
                return true;
            }
        }
        return false;
    }
    public void addInCategoryList(String category){
        if(category==null)return;
        for (int i=0;i<categoryListOfRestaurant.size();i++){
            if(categoryListOfRestaurant.get(i).equalsIgnoreCase(category))return;
        }
        categoryListOfRestaurant.add(category);
        return;

    }
    public void addUser(String name,String password)
    {
        int id=userlist.size()+1;
        userlist.add(new User(id,name,password));
    }
    public void addUser(int id,String name,String password)
    {
        userlist.add(new User(id,name,password));
    }
    public boolean _containsinFoodList(Food f,List<Food> fList){
        for(int i=0;i<fList.size();i++){
            if(fList.get(i).getName().equalsIgnoreCase(f.getName())){
                if(fList.get(i).getRestaurant_Id()==f.getRestaurant_Id()){
                    if(fList.get(i).getPrice()==f.getPrice()){
                        if(fList.get(i).getCategory().equalsIgnoreCase(f.getCategory())){
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    public boolean addRestaurant(Restaurant restaurant){
        //3
        //Case : Restaurent Already Exist
        if(_containsinRestaurantList(restaurant,restaurantList)){
            return false;
        }
        //Case : Category out Of Bound

        restaurantList.add(restaurant);
        addInCategoryList(restaurant.getCategories()[0]);
        addInCategoryList(restaurant.getCategories()[1]);
        addInCategoryList(restaurant.getCategories()[2]);
        return true;
    }
    public boolean addFood(Food food){
        //4
        //Case : Food Already Exist
        if(_containsinFoodList(food,foodList)){
            return false;
        }
        //Case : Category out Of Bound

        foodList.add(food);
        return true;
    }

    public List<Restaurant> SearchForRestaurantWithName(String restaurant){
        List<Restaurant> List=new ArrayList<>();
        //1.1
        for(int i=0;i<restaurantList.size();i++){
//            if(restaurantList.get(i).getName().equalsIgnoreCase(restaurant)){
            if(subStringBelongs(restaurant,restaurantList.get(i).getName())){
                List.add(restaurantList.get(i));
                //break;
            }
        }
        return List;
    }
    public List<Restaurant> SearchForRestaurantWithScore(double start,double end){
        //1.2
        List<Restaurant> List=new ArrayList<>();
        for(int i=0;i<restaurantList.size();i++){
            if(restaurantList.get(i).getScore()<=end && restaurantList.get(i).getScore()>=start){
                List.add(restaurantList.get(i));
                //break;
            }
        }
        return List;
    }

    public List<Restaurant> SearchForRestaurantWithCategory(String category){
        //1.3
        List<Restaurant> List=new ArrayList<>();
        for(int i=0;i<restaurantList.size();i++){
            String []s=restaurantList.get(i).getCategories();
//            if(s[0].equalsIgnoreCase(category) ||s[1].equalsIgnoreCase(category) || s[2].equalsIgnoreCase(category)){
            if(subStringBelongs(category,s[0]) ||subStringBelongs(category,s[1]) || subStringBelongs(category,s[2])){
                List.add(restaurantList.get(i));
                //break;
            }
        }
        return List;
    }
    public void addCustomer(String name,String Password) throws Exception {
        userlist.add(new User(userlist.size()+1,name,Password));
        try {
            UserFromFile.WriteIntoFile(userlist);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public List<Restaurant> SearchForRestaurantWithPrice(String price){
        //1.4
        List<Restaurant> List=new ArrayList<>();
        String test_String=new String();

        for(int i=0;i<restaurantList.size();i++){
            if(restaurantList.get(i).getPrice().equalsIgnoreCase(price)){
                List.add(restaurantList.get(i));
            }
        }
        return List;
    }

    public List<Restaurant> SearchForRestaurantWithZipCode(String zip){
        //1.5
        List<Restaurant> List=new ArrayList<>();
        for(int i=0;i<restaurantList.size();i++){
            if(restaurantList.get(i).getZip_code().equalsIgnoreCase(zip)){
                List.add(restaurantList.get(i));
                //break;
            }
        }
        return List;
    }

    public List<Food> SearchForFoodWithName(String food){
        //2.1
        List<Food> List=new ArrayList<>();

        for(int i=0;i<foodList.size();i++){
            if(subStringBelongs(food,foodList.get(i).getName())){
                List.add(foodList.get(i));
            }
        }
        return List;
    }
    public List<Food> SearchForFoodWithNameAndRestaurant(String food,String restaurant){
        //2.2
        List<Food> foodList=new ArrayList<>();
        foodList=SearchForFoodWithName(food);
        int indexOfRestaurent=-1;
        for(int i=0;i<restaurantList.size();i++){
            if(restaurantList.get(i).getName().equalsIgnoreCase(restaurant)){
                indexOfRestaurent=restaurantList.get(i).getId();
            }
        }
        List<Food> foodList2=new ArrayList<>();
        for(int i=0;i<foodList.size();i++){
            if(foodList.get(i).getRestaurant_Id()==indexOfRestaurent){
                foodList2.add(foodList.get(i));
                //break;
            }
        }
        return foodList2;
    }
    public List<Food> SearchForFoodWithRestaurant(String restaurant){
        //2.2
        List<Food> foodList=new ArrayList<>();
        foodList=this.foodList;
        int indexOfRestaurent=-1;
        for(int i=0;i<restaurantList.size();i++){
            if(restaurantList.get(i).getName().equalsIgnoreCase(restaurant)){
                indexOfRestaurent=restaurantList.get(i).getId();
            }
        }
        List<Food> foodList2=new ArrayList<>();
        for(int i=0;i<foodList.size();i++){
            if(foodList.get(i).getRestaurant_Id()==indexOfRestaurent){
                foodList2.add(foodList.get(i));
                //break;
            }
        }

        return foodList2;
    }
    public List<Food> SearchForFoodWithCategory(String category){
        //2.3
        List<Food> List=new ArrayList<>();

        for(int i=0;i<foodList.size();i++){
            if(subStringBelongs(category,foodList.get(i).getCategory())){
//            if(foodList.get(i).getCategory().equalsIgnoreCase(category)){
                List.add(foodList.get(i));
                //break;
            }
        }
        return List;
    }

    public List<Food> SearchForFoodWithCategoryandRestaurant(String category,String Restaurant){
        //2.4
        List<Food> foodList=new ArrayList<>();
        foodList=SearchForFoodWithCategory(category);
        int indexOfRestaurent=-1;
        for(int i=0;i<restaurantList.size();i++){
            if(restaurantList.get(i).getName().equalsIgnoreCase(Restaurant)){
                indexOfRestaurent=restaurantList.get(i).getId();
            }
        }
        List<Food> foodList2=new ArrayList<>();
        for(int i=0;i<foodList.size();i++){
            if(foodList.get(i).getRestaurant_Id()==indexOfRestaurent){
                foodList2.add(foodList.get(i));
                //break;
            }
        }
        return foodList2;
    }
    public List<Food> SearchForFoodWithPrice(double start,double end){
        //2.5
        List<Food> List=new ArrayList<>();

        for(int i=0;i<foodList.size();i++){
            if(foodList.get(i).getPrice()<=end && foodList.get(i).getPrice()>=start){
                List.add(foodList.get(i));
                //break;
            }
        }
        return List;
    }
    public List<Food> SearchForFoodWithPriceInRestaurant(double start,double end,String res){
        //2.6
        List<Food> List=new ArrayList<>();
        List=SearchForFoodWithPrice(start,end);
        List<Food> List2=new ArrayList<>();
        int indexOfRestaurent=-1;
        for(int i=0;i<restaurantList.size();i++){
            if(restaurantList.get(i).getName().equalsIgnoreCase(res)){
                indexOfRestaurent=restaurantList.get(i).getId();
            }
        }
        for(int i=0;i<List.size();i++){
            if(List.get(i).getRestaurant_Id()==indexOfRestaurent){
                List2.add(List.get(i));
                //break;
            }
        }
        return List2;
    }
    public List<Food> SearchForFoodWithCostliestInRestaurant(String res){
        //2.7
        List<Food> List=new ArrayList<>();
        int indexOfRestaurent=-1;
        for(int i=0;i<restaurantList.size();i++){
            if(restaurantList.get(i).getName().equalsIgnoreCase(res)){
                indexOfRestaurent=restaurantList.get(i).getId();
            }
        }
        //System.out.println(indexOfRestaurent);
        for(int i=0;i<foodList.size();i++){
            if(foodList.get(i).getRestaurant_Id()==indexOfRestaurent){
                List.add(foodList.get(i));
                //break;
            }
        }
        //System.out.println(List.size());
        double costliest=-1;
        for(int i=0;i<List.size();i++){
            if(List.get(i).getPrice()>costliest){
                costliest=List.get(i).getPrice();
            }
        }
        //System.out.println(costliest);
        List<Food> List2=new ArrayList<>();
        for(int i=0;i<List.size();i++){
            if(List.get(i).getPrice()==costliest){
                List2.add(List.get(i));
            }
        }
        return List2;
    }
}
