package util;

import models.Restaurant;

import java.io.Serializable;

public class Load implements Serializable {
    Restaurant restaurant;

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public Load(Restaurant restaurant) {
        this.restaurant = restaurant;
    }
}
