package util;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

import java.io.Serializable;

public class RegisterRequest implements Serializable {
    String category1;

    String category2;

    String category3;

    String name;

    String password;

    String price;

    String rating;

    String zipcode;


    public String getCategory1() {
        return category1;
    }

    public void setCategory1(String category1) {
        this.category1 = category1;
    }

    public String getCategory2() {
        return category2;
    }

    public void setCategory2(String category2) {
        this.category2 = category2;
    }

    public String getCategory3() {
        return category3;
    }

    public void setCategory3(String category3) {
        this.category3 = category3;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public RegisterRequest(String category1, String category2, String category3, String name, String password, String price, String rating, String zipcode) {
        this.category1 = category1;
        this.category2 = category2;
        this.category3 = category3;
        this.name = name;
        this.password = password;
        this.price = price;
        this.rating = rating;
        this.zipcode = zipcode;
    }
}
