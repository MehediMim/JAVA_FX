package client;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import models.Order;
import models.Restaurant;
import project.mim_.CustomerHomePage;
import project.mim_.RestaurantHomePageControl;
import requests.RestaurantLogin;
import util.Load;
import util.NetworkUtil;
import util.OrderlIst;
import util.Response;

import java.io.IOException;
import java.util.List;

public class RestaurantHome {
    public NetworkUtil getNetworkUtil() {
        return networkUtil;
    }

    public void setNetworkUtil(NetworkUtil networkUtil) {
        this.networkUtil = networkUtil;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public ActionEvent getActionEvent() {
        return actionEvent;
    }

    public void setActionEvent(ActionEvent actionEvent) {
        this.actionEvent = actionEvent;
    }

    NetworkUtil networkUtil;
    volatile Restaurant restaurant;
    Stage stage;
    ActionEvent actionEvent;



    public RestaurantHome(Restaurant restaurant, NetworkUtil networkUtil, ActionEvent actionEvent, Stage stage) {
        this.networkUtil=networkUtil;
        this.restaurant=restaurant;
        this.actionEvent=actionEvent;
        this.stage=stage;

        showPage(this);
    }

    public void showPage(RestaurantHome restaurantHome) {
                try {
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("RestaurantHomePage.fxml"));
                            Parent root = loader.load();
                            RestaurantHomePageControl controller = loader.getController();
                            System.out.println("Recieved_");
                    Load load =new Load(restaurant);
                            networkUtil.write(load);
                            System.out.println("sent_");
                            //OrderlIst orderlIst = (OrderlIst) networkUtil.read();

                            //System.out.println("Recieved_ "+orderlIst.getOrderList().size());
                            List<Order>ol= (List<Order>) networkUtil.read();
                            for(Order order:ol){
                                System.out.println(order.getFood());
                            }
                            controller.setMain(this,ol);
                            controller.init();

                            stage.setTitle("Customer");
                            stage.setScene(new Scene(root));
                            stage.show();

                } catch (Exception e) {
                    System.out.println("ERROR: " + e);
                }
    }
    public List<Order> getListt() throws IOException, ClassNotFoundException {
        networkUtil.write(restaurant);
        System.out.println("sent_");
        OrderlIst orderlIst = (OrderlIst) networkUtil.read();
        System.out.println("Recieved_ "+orderlIst.getOrderList().size());
        return orderlIst.getOrderList();
    }


}
