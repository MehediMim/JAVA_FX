package util;

import models.Food;
import models.User;

import java.io.Serializable;

public class OrderRequest  implements Serializable {
    User user;
    Food food;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Food getFood() {
        return food;
    }

    public void setFood(Food food) {
        this.food = food;
    }

    public OrderRequest(User user, Food food) {
        this.user = user;
        this.food = food;
    }
}
