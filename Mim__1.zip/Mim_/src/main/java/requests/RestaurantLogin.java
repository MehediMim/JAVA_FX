package requests;

import java.io.Serializable;

public class RestaurantLogin implements Serializable {
    private String restaurantname;
    private String restaurantpassword;
    private String response;

    public RestaurantLogin(String restaurantname, String restaurantpassword) {
        this.restaurantname = restaurantname;
        this.restaurantpassword = restaurantpassword;
        response="";
    }
    public RestaurantLogin() {
        this.restaurantname ="";
        this.restaurantpassword = "";
        response="";
    }

    public String getRestaurantname() {
        return restaurantname;
    }

    public void setRestaurantname(String restaurantname) {
        this.restaurantname = restaurantname;
    }

    public String getRestaurantpassword() {
        return restaurantpassword;
    }

    public void setRestaurantpassword(String restaurantpassword) {
        this.restaurantpassword = restaurantpassword;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }
}
