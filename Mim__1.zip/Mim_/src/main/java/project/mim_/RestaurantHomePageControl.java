package project.mim_;

import client.Fooditems;
import client.Ordersmini;
import client.RestaurantHome;
import client.customerHome;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import models.Food;
import models.Order;

import java.io.IOException;
import java.util.List;

public class RestaurantHomePageControl {
    @FXML
    private AnchorPane black;
    @FXML
    private GridPane grid;

    @FXML
    private ScrollPane scroll;

    @FXML
    private Label nameLabel;

    @FXML
    private Label ratinglabel;

    public AnchorPane getBlack() {
        return black;
    }

    public void setBlack(AnchorPane black) {
        this.black = black;
    }

    public Label getNameLabel() {
        return nameLabel;
    }

    public void setNameLabel(Label nameLabel) {
        this.nameLabel = nameLabel;
    }

    public Label getRatinglabel() {
        return ratinglabel;
    }

    public void setRatinglabel(Label ratinglabel) {
        this.ratinglabel = ratinglabel;
    }

    public RestaurantHome getRestaurantHome() {
        return _restaurantHome;
    }

    public void setRestaurantHome(RestaurantHome restaurantHome) {
        this._restaurantHome = restaurantHome;
    }

    public List<Order> getOrders() {
        return orders;
    }

    RestaurantHome _restaurantHome;
    private List<Order> orders;

    public GridPane getGrid() {
        return grid;
    }

    public void setGrid(GridPane grid) {
        this.grid = grid;
    }

    public ScrollPane getScroll() {
        return scroll;
    }

    public void setScroll(ScrollPane scroll) {
        this.scroll = scroll;
    }


    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }




    public void PendingOrderButtonPressed(ActionEvent actionEvent) throws IOException, ClassNotFoundException {
       // System.out.println("");
        _restaurantHome.showPage(_restaurantHome);
        //orders=restaurantHome.getListt();
        LoadList();
    }



    public void setMain(RestaurantHome restaurantHome,List<Order>orderList) throws IOException, ClassNotFoundException {
        this._restaurantHome=restaurantHome;
        this.orders=orderList;
        try {
            LoadList();
        } catch (IOException e) {
            System.out.println(e);
        } catch (ClassNotFoundException e) {
            System.out.println(e);
        }
    }

    public void LoadList() throws IOException, ClassNotFoundException {
        //List<Order>orderList;
        //orderList=restaurantHome.getListt();
        //System.out.println("Orderlist size"+orderList.size());
        //orders.clear();
        //orders=;
        //orders.addAll(getOrders());

        int column =0;
        int row =1;
        try {
            for (int i = 0; i < orders.size(); i++) {
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("ordersmini.fxml"));
                AnchorPane anchorPane = fxmlLoader.load();
                Ordersmini itemController = fxmlLoader.getController();
                itemController.setData(orders.get(i),_restaurantHome);
                if (column == 3) {
                    column = 0;
                    row++;
                }
                grid.add(anchorPane, column++, row); //(child,column,row)
                //set grid width
                grid.setMinWidth(Region.USE_COMPUTED_SIZE);
                grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
                grid.setMaxWidth(Region.USE_PREF_SIZE);

                //set grid height
                grid.setMinHeight(Region.USE_COMPUTED_SIZE);
                grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
                grid.setMaxHeight(Region.USE_PREF_SIZE);

                GridPane.setMargin(anchorPane, new Insets(10));
            }
        } catch (IOException e) {
            System.out.println("HAE ERROR "+e);
        }
    }

    public void init() {
        nameLabel.setText(_restaurantHome.getRestaurant().getName());
        ratinglabel.setText(_restaurantHome.getRestaurant().getRating());
        //loadListInBackground();

    }
}
