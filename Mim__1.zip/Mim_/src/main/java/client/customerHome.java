package client;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import models.Food;
import models.User;
import project.mim_.CustomerHomePage;
import util.Customer;
import util.NetworkUtil;
import util.Response;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class customerHome {

    User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    Stage stage=new Stage();
    NetworkUtil networkUtil;
    Response response;
    public String string=new String();

    public customerHome(NetworkUtil networkUtil, User user, Stage stage) throws IOException, ClassNotFoundException {
        this.networkUtil=networkUtil;
        this.user=user;
        this.stage=stage;
        CustomerHome();
    }



    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public NetworkUtil getNetworkUtil() {
        return networkUtil;
    }

    public void setNetworkUtil(NetworkUtil networkUtil) {
        this.networkUtil = networkUtil;
    }

    public Response getResponse() {
        return response;
    }

    public void setResponse(Response response) {
        this.response = response;
    }

    private void CustomerHome() throws IOException, ClassNotFoundException {
        showPage();


    }

    public String getString() {
        return string;
    }

    public void setString(String string) {
        System.out.println("SOMOSSA");
        this.string = string;
    }

    public void SearchCategory() throws IOException, ClassNotFoundException {

        Response response=new Response("SearchCategory",string);
        try {
            networkUtil.write(response);
        } catch (IOException e) {
            System.out.println("Line 68 : customerHome");
        }
        Response result= (Response) networkUtil.read();
        System.out.println("Got the list");
        List<Food>foodListList=(List<Food>)result.getData();
        System.out.println(result.getMessage());
        for(Food food:foodListList){
            System.out.println(food);
        }
        System.out.println("Thanks");
    }
    private void showPage()
    {

        try{
            System.out.println("Customerhomepaghe e acghi bhai");

            FXMLLoader loader = new FXMLLoader(getClass().getResource("CustomerHomePage.fxml"));
            Parent root = null;
            try {
                root = loader.load();
            } catch (Exception e) {
                System.out.println("Line 59 : Client :" + e);
            }
            // Loading the controller
            CustomerHomePage controller = loader.getController();
            controller.setMain(this);
            controller.init();

            // Set the primary stage
            //stage=new Stage();
            stage.setTitle("Customer");
            //setIcon(stage);
            stage.setScene(new Scene(root));
            stage.show();
        }
        catch (Exception e){
            System.out.println("ERROR 76 "+ e);

        }
    }

    public void SearchRestaurant() throws IOException, ClassNotFoundException {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter Restaurant Name");
        String restaurantname= scanner.nextLine();
        Response response=new Response("SearchRestaurant",restaurantname);
        try {
            networkUtil.write(response);
        } catch (IOException e) {
            System.out.println("Line 50 : customerHome");
        }
        Response result= (Response) networkUtil.read();
        System.out.println("Got the list");
        List<Food>foodListList=(List<Food>)result.getData();
        System.out.println(result.getMessage());
        for(Food food:foodListList){
            System.out.println(food);
        }
        System.out.println("Thanks");

    }

    public void SearchFood() throws IOException, ClassNotFoundException {
        System.out.println("CALLINGGGGGGGG");
        Response response=new Response("SearchFood",string);
        try {
            networkUtil.write(response);
        } catch (IOException e) {
            System.out.println("Line 73 : customerHome");
        }
        Response result= (Response) networkUtil.read();
        System.out.println("Got the list");
        List<Food>foodList=(List<Food>)result.getData();

        System.out.println(result.getMessage());
        for(Food food:foodList){
            System.out.println(food);
        }
        System.out.println("Thanks");
        /////////////////
        FXMLLoader loader = new FXMLLoader(getClass().getResource("FoodShowMain.fxml"));
        Parent root = null;
        try {
            root = loader.load();
            System.out.println("Done1");
        } catch (Exception e) {
            System.out.println("Line 59 : Client :" + e);
        }
        // Loading the controller
            System.out.println("Done2");
        FoodShowMain controller = loader.getController();
            System.out.println("Done3");
        controller.setMain(this,foodList);
            System.out.println("Done4");
        controller.init();
            System.out.println("Done5");

        // Set the primary stage
        //stage=new Stage();
        stage.setTitle("Customer");
            System.out.println("Done3");
        //setIcon(stage);
        stage.setScene(new Scene(root));
        stage.show();
    }

}
