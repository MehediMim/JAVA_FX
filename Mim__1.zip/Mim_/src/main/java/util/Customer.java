package util;

import java.io.Serializable;

public class Customer implements Serializable {
    private int id;
    private String name;

}
