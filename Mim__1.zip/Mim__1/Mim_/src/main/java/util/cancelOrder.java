package util;

import models.Order;

import java.io.Serializable;

public class cancelOrder implements Serializable {
    private Order order;

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public cancelOrder(Order order) {
        this.order = order;
    }
}
