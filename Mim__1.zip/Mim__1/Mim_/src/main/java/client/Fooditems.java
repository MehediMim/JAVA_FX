package client;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import models.Food;
import models.Order;
import project.mim_.CustomerHomePage;
import requests.CustomerLogin;
import util.NetworkUtil;
import util.OrderRequest;
import util.Response;

import java.io.IOException;
import java.util.Objects;
import java.util.Random;

public class Fooditems {

    public Food food;
    @FXML
    private ImageView picture;

    @FXML
    private Label foodname;

    @FXML
    private Label category;

    @FXML
    private Label price;


    @FXML
    private Button orderButtonPressed;

    customerHome _customerHome;
    private String[] imageUrls = {
            "/image/1.png",
            "/image/2.png",
            "/image/3.png",
            "/image/4.png",
            //"image/fresh-pasta-with-hearty-bolognese-parmesan-cheese-generated-by-ai.jpg",
            //"image/fresh-pasta-with-hearty-bolognese-parmesan-cheese-generated-by-ai.jpg"
            // Add more image paths as needed
    };
    NetworkUtil networkUtil;

    public void setData(Food food,customerHome customerHome){
        this.food=food;
        foodname.setText((String) food.getName());
        price.setText("$" +(String.valueOf(food.getPrice())));
        category.setText((String) food.getCategory());
        this._customerHome=customerHome;
        networkUtil=_customerHome.getNetworkUtil();
        Random random = new Random();
        int randomIndex = random.nextInt(imageUrls.length);
        String imageUrl = imageUrls[randomIndex];
        Image image = new Image(Objects.requireNonNull(getClass().getResourceAsStream(imageUrl)));
        picture.setImage(image);
    }
    public void setData(Food food){
        this.food=food;
        foodname.setText((String) food.getName());
        price.setText("$" +(String.valueOf(food.getPrice())));
        category.setText((String) food.getCategory());
        //orderButtonPressed.setOpacity(0.00);
        //this._customerHome=customerHome;
        //networkUtil=_customerHome.getNetworkUtil();
    }

    public void button(ActionEvent actionEvent) {
        orderButtonPressed.disabledProperty();
        orderButtonPressed.setText("ORDERED");
        orderButtonPressed.setStyle("-fx-background-color: #191970;");

        System.out.println("button pressed for food "+food.getName());
        OrderRequest orderRequest=new OrderRequest(_customerHome.getUser(),food);
        try {
            System.out.println("WRITING in Server");
            networkUtil.write(orderRequest);
        } catch (IOException e) {
            System.out.println("New Error "+e);
        }

    }
}
